asect 0x00
start:
	ldi r0, 0xF3
	ld r0, r0
	ldi r2, 0b00000100
	if
		and r0, r2
	is nz
		br start
	else
	fi
	ldi r1, 0xF4
	ld r1, r1
	ldi r2, 24
	if
		cmp r1, r2
	is le
		br start
	else
	fi
	ldi r2, 224
	sub r2, r1
	move r1, r1
	shr r1
	ldi r2, 0b00100000
	ldi r3, 0xF5
	ld r3, r3
	if
		and r0, r2
	is nz
		if
			sub r3, r1
		is mi
			if
			is cc
				neg r1
			fi
		fi	
	else
		if
			add r3, r1
		is cs
			neg r1
		fi
	fi
	move r0, r0
	shr r1
	shr r1
	shr r1
	dec r1
	ldi r2, 0xF3
	st r2, r1
	br start
end
 